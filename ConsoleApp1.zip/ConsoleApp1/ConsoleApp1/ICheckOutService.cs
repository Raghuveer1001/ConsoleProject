﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public interface ICheckOutService 
    {
         void Add(Item item);
        void ReviewItems();
        public float CalculateDiscountedPrice(string item);
    }
}
