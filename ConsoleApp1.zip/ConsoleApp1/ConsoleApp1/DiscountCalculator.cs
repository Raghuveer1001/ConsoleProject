﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class DiscountCalculator
    {
        private static DiscountCalculator _instance;
        private static List<Scheame> _scheames;
        private DiscountCalculator(List<Scheame> scheames)
        {
            _scheames = scheames;
        }
        public static DiscountCalculator Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DiscountCalculator(StaticDataCollection.scheames);
                return _instance;
            }
        }
        public float GetDiscount(int category, float price, int units)
        {
            //here we have tow option to apply if user scans more that 3 units then 30 discount should be apply on all.
            //for that we neet to write either switch cases but that need to be modied of any new middle discounts some
            //Or we can fetch discount from procedure using between keyword
            //
            var match = _scheames.Where(x => x.CategoryId == category && x.units == units).FirstOrDefault();
            if (match == null)
                return 0f;
            return (price * units) - match.DiscountAmount;
        }
    }
}
