﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class ItemScannner : IItemScannner
    {
        ICheckOutService _checkOutService;
        public ItemScannner(ICheckOutService checkOutService)
        {
            _checkOutService = checkOutService;

        }
        public bool scan(string item)
        {
            var match = StaticDataCollection.items.Where(x => x.Name == item).FirstOrDefault();
            if (match == null)
            {
                return false;
            }
            
            _checkOutService.Add(match);
            return true;
        }
    }
}
