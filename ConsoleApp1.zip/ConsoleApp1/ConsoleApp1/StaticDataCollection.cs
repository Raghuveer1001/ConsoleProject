﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class StaticDataCollection
    {
        public static List<ItemCategory> AllCategories = new List<ItemCategory>();
        public static List<Item> items = new List<Item>();
        public static List<Scheame> scheames = new List<Scheame>();
        static StaticDataCollection()
        {
            AllCategories.Add(new ItemCategory() { Id = 1, Name = "Cat_1" });
            AllCategories.Add(new ItemCategory() { Id = 1, Name = "Cat_2" });
            AllCategories.Add(new ItemCategory() { Id = 2, Name = "Cat_3" });

            items.Add(new Item() { Id = 1, Name = "A", CategoryId = 1, Price = 50 });
            items.Add(new Item() { Id = 2, Name = "B", CategoryId = 1, Price = 30 });
            items.Add(new Item() { Id = 3, Name = "C", CategoryId = 2, Price = 20 });
            items.Add(new Item() { Id = 4, Name = "D", CategoryId = 2, Price = 15 });

            scheames.Add(new Scheame() { CategoryId = 1, units = 3, DiscountAmount = 20 });
            scheames.Add(new Scheame() { CategoryId = 1, units = 2, DiscountAmount = 15 });


        }

    }
}
