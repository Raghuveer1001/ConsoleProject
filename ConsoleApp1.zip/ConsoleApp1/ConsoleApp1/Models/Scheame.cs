﻿
namespace ConsoleApp1
{
    public class Scheame
    {
        public int CategoryId { get; set; }
        //public float DiscountPercentage { get; set; }
        public float DiscountAmount { get; set; }
        public int units { get; set; }
    }
}
