﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class ItemCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
