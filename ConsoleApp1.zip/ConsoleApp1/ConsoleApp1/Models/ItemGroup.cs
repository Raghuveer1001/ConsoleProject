﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    public class ItemGroup :IEnumerable<Item>
    {
        IEnumerable<Item> _items;
        public ItemGroup(IEnumerable<Item> items)
        {
            _items = items;
            
        }
        public int ItemId { get { return _items.First().Id; } }
        public string Name { get { return _items.First().Name; } }
        public int Units { get { return _items.Count(); } }
        public float TotalPrice { get { return _items.Sum(x => x.Price); } }
        
        public int categoryId { get {return _items.First().CategoryId; } }
        public Item Item { get { return _items.First(); } }
        public IEnumerator<Item> GetEnumerator()
        {
            return this._items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this._items as System.Collections.IEnumerator;
        }
    }
}
