﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            ICheckOutService checkOutService = new CheckOutService();

            IItemScannner itemScannner = new ItemScannner(checkOutService);

            itemScannner.scan("A");
            itemScannner.scan("B");
            itemScannner.scan("A");
            itemScannner.scan("A");
            itemScannner.scan("B");
            itemScannner.scan("C");
            itemScannner.scan("D");

            checkOutService.ReviewItems();

        }
    }
}
