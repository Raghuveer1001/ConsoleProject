﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class CheckOutService : ICheckOutService
    {
        public CheckOutService()
        {
        }
        List<Item> items=new List<Item>();
        public void Add(Item item)=>items.Add(item);

        public float CalculateDiscountedPrice(string item)
        {
            var match = from eachItem in items where eachItem.Name == item select eachItem;
            if(match==null)
                return 0;

            return DiscountCalculator.Instance.GetDiscount(match.First().CategoryId, match.First().Price, match.Count());
        }
        public void ReviewItems()
        {
            Console.WriteLine("********************** Displaying Scanned Product Details ********************* ");
            var groups = from eachItem in items 
                         group eachItem by eachItem.Name
                         into grp
                         select new ItemGroup(grp.ToList());
            Console.WriteLine("Name:   |   Units  | Price Per Unit | TotalPrice | DiscountedPrice ");

            foreach (var item in groups)
            {
                
                Console.WriteLine(item.Name + " | " + item.Units + " | " + items.Where(x => x.Id == item.ItemId).First().Price + " | " +item.TotalPrice+ " | " + DiscountCalculator.Instance.GetDiscount(item.categoryId,item.Item.Price,item.Units));
            }
        }
        

    }
}
