﻿using ConsoleApp1;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestProject1
{
    internal class CheckoutTest 
    {

     

        [Test]
        public void ScanAndCheckOut()
        {

            ICheckOutService checkOutService = new CheckOutService();

            IItemScannner itemScannner = new ItemScannner(checkOutService);

            itemScannner.scan("A");
            itemScannner.scan("A");
            itemScannner.scan("B");
            itemScannner.scan("B");
            itemScannner.scan("A");

            //Assert.AreEqual(checkOutService.CalculateDiscountedPrice("A"),130f);
  //          Assert.AreEqual(checkOutService.CalculateDiscountedPrice("B"), 45f);
            Assert.AreNotEqual(checkOutService.CalculateDiscountedPrice("B"), 45f);
        }
    }
}
